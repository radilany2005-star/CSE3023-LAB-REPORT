<%@page contentType="text/html" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<head>
    <title>Car Loan Result</title>
    <style>
        body {
            font-family: Arial;
        }

        h1 {
            font-weight: bold;
        }

        fieldset {
            width: 500px;
            padding: 15px;
        }

        .title {
            color: blue;
            font-size: 20px;
            font-weight: bold;
        }
    </style>
</head>

<body>

<h1>Perform Car Loan Calculation</h1>

<%
    // Get values
    double loan = Double.parseDouble(request.getParameter("amount"));
    int period = Integer.parseInt(request.getParameter("period"));

    // Interest rate (example 5%)
    double rate = 0.05;

    // Calculate total loan
    double totalLoan = loan + (loan * rate * period);
%>

<fieldset>
    <p class="title">Details of car loan:</p>

    <p>Loan Request : <%= loan %></p>
    <p>Period of payment : <%= period %></p>
    <p>Total Loan (+ interest) : <%= totalLoan %></p>
</fieldset>

&copy;2026-Syafiq

</body>
</html>