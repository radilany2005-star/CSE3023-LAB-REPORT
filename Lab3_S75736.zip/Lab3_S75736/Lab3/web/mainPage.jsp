<%-- 
    Document   : mainPage
    Created on : 14 Apr 2026, 3:56:05 pm
    Author     : radil
--%>

<%@page contentType="text/html" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<head>
    <title>Main Page</title>

    <style>
        body {
            margin: 0;
            font-family: Arial;
        }

        .header {
            background-color: #e6cfae;
            text-align: center;
            padding: 20px;
            font-size: 28px;
            font-weight: bold;
        }

        .content {
            background-color: #eeeeee;
            padding: 20px;
            color: red;
            height: 150px;
        }

        .footer {
            background-color: #e6cfae;
            text-align: center;
            padding: 10px;
        }
    </style>
</head>

<body>

<!-- Header -->
<div class="header">
    ABC Sdn Bhd
</div>

<!-- Content -->
<div class="content">
    Java Server Page (JSP) is a technology for controlling the content <br>
    or appearance of Web pages through the use of servlets, small <br>
    programs that are specified in the Web page and run on the Web server <br>
    to modify the Web page before it is sent to the user who requested it.
</div>

<!-- Footer -->
<div class="footer">
    ©2026-Syaffiq
</div>

</body>
</html>
