<%-- 
    Document   : populateArray
    Created on : 14 Apr 2026, 2:59:28 pm
    Author     : radil
--%>


<%@page contentType="text/html" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<head>
    <title>Salesman Sales</title>
    <style>
        table {
            border-collapse: collapse;
            margin-top: 20px;
            wigth: 50%;
        }
        th, td {
            border: 1px solid black;
            padding: 10px;
            text-align: center;
        }
        h2 {
            text-align: center;
        }
        th {
        background-color: #d6b56c; /* gold header */
        padding: 10px;
    }

         tr:nth-child(even) {
        background-color: #f2f2f2; /* light grey rows */
    }

    tr:nth-child(odd) {
        background-color: #e6e0d4; /* beige rows */
    }

    </style>
</head>

<body>

<h2>Read Java array and populate it into HTML table</h2>

<%
    // Step 1: Create array (rows = salesman, columns = months)
    int sales[][] = {
        {2500, 2100, 2200},
        {2000, 1900, 2400},
        {1800, 2200, 2450}
    };

    String salesman[] = {"Salesman 1", "Salesman 2", "Salesman 3"};
%>
<center>
<table>
    <tr>
        <th>Salesman</th>
        <th>Jan</th>
        <th>Feb</th>
        <th>Mar</th>
    </tr>

<%
    // Step 2: Loop through array and display data
    for(int i = 0; i < sales.length; i++) {
%>
    <tr>
        <td><%= salesman[i] %></td>
        <td><%= sales[i][0] %></td>
        <td><%= sales[i][1] %></td>
        <td><%= sales[i][2] %></td>
    </tr>
<%
    }
%>

</table>
</center>
<p>©2026-Syaffiq</p>

</body>
</html>
