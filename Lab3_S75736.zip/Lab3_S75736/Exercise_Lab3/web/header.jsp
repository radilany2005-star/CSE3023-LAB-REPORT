<%-- 
    Document   : header
    Created on : 14 Apr 2026, 4:03:11?pm
    Author     : radil
--%>

<div style="background:#e6cfae; padding:20px; text-align:center;">
    <h2>Student Clud Recruitment Week Sdn Bhd</h2>

    <a href="mainPage.jsp">Home</a> |
    <a href="registerClub.jsp">Registration</a> |
    <a href="feeCalculator.jsp">Fee Calculator</a> |
    <a href="memberDirectory.jsp">Member Directory</a>
</div>
