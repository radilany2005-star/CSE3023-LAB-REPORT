<%-- 
    Document   : mainPage
    Created on : 14 Apr 2026, 4:05:21 pm
    Author     : radil
--%>

<%@page contentType="text/html" pageEncoding="UTF-8"%>
<%@ include file="header.jsp" %>

<h2>Welcome to Student Club System</h2>

<p>This system allows registration and fee calculation.</p>

<%@ include file="footer.jsp" %>
