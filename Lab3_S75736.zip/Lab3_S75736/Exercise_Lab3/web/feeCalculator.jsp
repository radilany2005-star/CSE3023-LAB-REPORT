<%-- 
    Document   : feeCalculator
    Created on : 14 Apr 2026, 4:04:44 pm
    Author     : radil
--%>

<%@page contentType="text/html" pageEncoding="UTF-8"%>
<%@ include file="header.jsp" %>

<h2>Fee Calculator</h2>

<form method="get">
    Number of Activities: 
    <input type="text" name="activity">
    <input type="submit" value="Calculate">
</form>

<%
    if(request.getParameter("activity") != null){
        int activity = Integer.parseInt(request.getParameter("activity"));
        double total = activity * 10;
%>

<p>Total Fee: RM <%= String.format("%.2f", total) %></p>

<%
    }
%>

<%@ include file="footer.jsp" %>
