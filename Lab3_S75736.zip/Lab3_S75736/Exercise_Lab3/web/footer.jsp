<%-- 
    Document   : footer
    Created on : 14 Apr 2026, 4:03:26?pm
    Author     : radil
--%>

<div style="background:#e6cfae; text-align:center; padding:10px;">
    &copy;2026-Radilan
</div>