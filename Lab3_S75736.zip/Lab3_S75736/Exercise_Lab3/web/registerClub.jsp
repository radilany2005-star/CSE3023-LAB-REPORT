<%-- 
    Document   : registerClub
    Created on : 14 Apr 2026, 4:03:57 pm
    Author     : radil
--%>

<%@page contentType="text/html" pageEncoding="UTF-8"%>
<%@ include file="header.jsp" %>

<h2>Club Registration</h2>

<form action="processRegistration.jsp" method="get">
    Name: <input type="text" name="name"><br><br>
    Matric No: <input type="text" name="matric"><br><br>

    Club:
    <select name="club">
        <option>Programming Club</option>
        <option>Multimedia Club</option>
        <option>Sports Club</option>
    </select><br><br>

    <input type="submit" value="Register">
</form>

<%@ include file="footer.jsp" %>