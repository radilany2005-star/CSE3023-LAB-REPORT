<%-- 
    Document   : processRegistration
    Created on : 14 Apr 2026, 4:04:18 pm
    Author     : radil
--%>

<%@page contentType="text/html" pageEncoding="UTF-8"%>
<%@ page import="java.util.ArrayList" %>
<%@ include file="header.jsp" %>

<%
    String name = request.getParameter("name");
    String matric = request.getParameter("matric");
    String club = request.getParameter("club");

    // Get existing list
    ArrayList<String[]> members = (ArrayList<String[]>) application.getAttribute("members");

    if (members == null) {
        members = new ArrayList<String[]>();
    }

    // Store as array [name, matric, club]
    String[] member = {name, matric, club};
    members.add(member);

    // Save back
    application.setAttribute("members", members);
%>

<h2>Registration Successful</h2>

<p>Name: <%= name %></p>
<p>Matric No: <%= matric %></p>
<p>Club: <%= club %></p>

<br>
<a href="memberDirectory.jsp">View Member Directory</a>

<%@ include file="footer.jsp" %>
