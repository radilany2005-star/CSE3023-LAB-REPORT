<%-- 
    Document   : memberDirectory
    Created on : 14 Apr 2026, 4:05:01 pm
    Author     : radil
--%>

<%@page contentType="text/html" pageEncoding="UTF-8"%>
<%@ page import="java.util.ArrayList" %>
<%@ include file="header.jsp" %>

<h2>Club Member Directory</h2>

<%
    ArrayList<String[]> members = (ArrayList<String[]>) application.getAttribute("members");
%>

<table border="1" cellpadding="10">
<tr>
    <th>Name</th>
    <th>Matric No</th>
    <th>Club</th>
</tr>

<%
    if (members != null) {
        for (String[] m : members) {
%>
<tr>
    <td><%= m[0] %></td>
    <td><%= m[1] %></td>
    <td><%= m[2] %></td>
</tr>
<%
        }
    } else {
%>
<tr>
    <td colspan="3">No members registered yet</td>
</tr>
<%
    }
%>

</table>

<%@ include file="footer.jsp" %>
